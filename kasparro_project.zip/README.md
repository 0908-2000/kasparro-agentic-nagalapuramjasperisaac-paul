# Kasparro — Multi-Agent Content Generation (Minimal Implementation)

This repository demonstrates a clean, maintainable, agent-style pipeline that converts
product JSON into structured page JSONs (FAQ, Product Page, Comparison).

Quickstart:
  python run_pipeline.py --input data/product_fixture.json --out_dir output
