import subprocess
from pathlib import Path

def test_run_pipeline_creates_output(tmp_path):
    out = tmp_path / 'out'
    cmd = ['python', 'run_pipeline.py', '--input', 'data/product_fixture.json', '--out_dir', str(out)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, res.stderr
    assert (out / 'faq.json').exists()
    assert (out / 'product_page.json').exists()
    assert (out / 'comparison_page.json').exists()
