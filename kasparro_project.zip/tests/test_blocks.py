import json
from agents.parser import ParserAgent
from agents.content_blocks import benefits_block, usage_block, compare_ingredients_block

def load_fixture():
    with open('data/product_fixture.json','r',encoding='utf8') as f:
        return json.load(f)

def test_benefits_and_usage():
    data = load_fixture()
    parser = ParserAgent()
    p = parser.run(data['product_A'])
    b = benefits_block(p)
    assert isinstance(b, list) and len(b) > 0
    u = usage_block(p)
    assert 'how_to_use' in u

def test_compare_ingredients():
    data = load_fixture()
    parser = ParserAgent()
    a = parser.run(data['product_A'])
    b = parser.run(data['product_B'])
    comp = compare_ingredients_block(a,b)
    assert 'common' in comp and isinstance(comp['common'], list)
