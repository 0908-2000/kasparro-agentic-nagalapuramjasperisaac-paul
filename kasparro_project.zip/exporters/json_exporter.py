import json, os
from typing import Any, Dict
class JSONExporterAgent:
    def write(self, page_json: Dict[str,Any], out_path: str):
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        with open(out_path, 'w', encoding='utf8') as f:
            json.dump(page_json, f, ensure_ascii=False, indent=2)
        return out_path
