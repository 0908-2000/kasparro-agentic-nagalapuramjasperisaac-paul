from dataclasses import dataclass
from typing import List, Dict, Any

@dataclass
class ProductModel:
    id: str
    name: str
    concentration: str
    skin_types: List[str]
    ingredients: List[str]
    benefits: List[str]
    usage: Dict[str, str]
    side_effects: List[str]
    price: Dict[str, Any]

class ParserAgent:
    def run(self, raw: Dict) -> ProductModel:
        required = ['id','name','concentration','skin_types','ingredients','benefits','usage','side_effects','price']
        for r in required:
            if r not in raw:
                raise ValueError(f"Missing required field: {r}")
        skin = raw.get('skin_types') or []
        if isinstance(skin, str):
            skin = [s.strip() for s in skin.split(',') if s.strip()]
        return ProductModel(
            id=str(raw['id']),
            name=str(raw['name']),
            concentration=str(raw.get('concentration','')),
            skin_types=skin,
            ingredients=[i.strip() for i in raw.get('ingredients',[])],
            benefits=[b.strip() for b in raw.get('benefits',[])],
            usage=raw.get('usage',{}),
            side_effects=[s.strip() for s in raw.get('side_effects',[])],
            price=raw.get('price',{})
        )
