from typing import List, Dict
from .parser import ProductModel

class QuestionGeneratorAgent:
    def run(self, product: ProductModel) -> List[Dict]:
        name = product.name
        q = []
        q.append({'id':1,'category':'Informational','question':f'What is {name} and what concentration does it contain?'})
        q.append({'id':2,'category':'Informational','question':f'Which skin types is {name} formulated for?'})
        q.append({'id':3,'category':'Usage','question':f'How should I incorporate {name} into my daily routine?'})
        q.append({'id':4,'category':'Usage','question':f'How many drops/amount of {name} should I apply and how often?'})
        q.append({'id':5,'category':'Safety','question':f'What side effects can I expect from {name} and when to consult a professional?'})
        for idx,ing in enumerate(product.ingredients[:5], start=6):
            q.append({'id':idx,'category':'Ingredients','question':f'What does {ing} do in {name}?' })
        q.append({'id':20,'category':'Comparison','question':f'How does {name} compare to similar serums in concentration and ingredients?'})
        q.append({'id':21,'category':'Purchase','question':f'What is the price of {name} and where can I buy it?'})
        q.append({'id':22,'category':'Results','question':f'How long to see visible results with {name}?'})
        q.append({'id':23,'category':'Storage','question':f'How should {name} be stored to preserve potency?'})
        next_id = 24
        extras = ['Compatibility with retinol or acids','Recommended age groups','Patch-test advice','Best time of day to use','Frequency for sensitive skin','Interactions with sunscreen']
        for e in extras:
            q.append({'id':next_id,'category':'Practical','question':f'{e} for {name}?' })
            next_id += 1
        return q
