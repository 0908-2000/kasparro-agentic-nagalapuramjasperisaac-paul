from typing import Dict, List
from .parser import ProductModel

def extract_name_block(product: ProductModel) -> Dict:
    short = product.name.split(' ')[0]
    return {'name': product.name, 'short_name': short}

def benefits_block(product: ProductModel) -> List[Dict]:
    return [{'title': b, 'detail': f"Key benefit: {b}."} for b in product.benefits]

def usage_block(product: ProductModel) -> Dict:
    how = product.usage.get('how_to_use') if isinstance(product.usage, dict) else product.usage
    freq = product.usage.get('frequency') if isinstance(product.usage, dict) else ''
    return {'how_to_use': how or '', 'frequency_hint': freq or 'Follow label instructions.'}

def safety_block(product: ProductModel) -> Dict:
    return {'side_effects': product.side_effects, 'advice': 'Patch test recommended for sensitive skin; discontinue if irritation occurs.'}

def compare_ingredients_block(a: ProductModel, b: ProductModel) -> Dict:
    setA = set([i.lower() for i in a.ingredients])
    setB = set([i.lower() for i in b.ingredients])
    return {
        'common': sorted(list(setA & setB)),
        'unique_to_A': sorted(list(setA - setB)),
        'unique_to_B': sorted(list(setB - setA))
    }

def price_block(product: ProductModel) -> Dict:
    p = product.price or {}
    return {'currency': p.get('currency','INR'), 'amount': p.get('amount',0)}
