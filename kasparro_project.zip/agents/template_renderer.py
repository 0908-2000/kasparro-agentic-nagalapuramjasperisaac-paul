from typing import Dict, Any
from .parser import ProductModel
from .content_blocks import extract_name_block, benefits_block, usage_block, safety_block, price_block, compare_ingredients_block

class TemplateRendererAgent:
    def render_faq(self, product: ProductModel, questions: list) -> Dict[str, Any]:
        benefits = [b['title'] for b in benefits_block(product)]
        usage = usage_block(product)
        safety = safety_block(product)
        qlist = []
        for q in questions[:12]:
            qlist.append({'q': q['question'], 'a': self._answer_stub(q, product)})
        return {
            'title': f"{product.name} — FAQ",
            'product_name': product.name,
            'last_updated': '2025-12-27',
            'questions': qlist,
            'blocks_summary': {
                'benefits': benefits,
                'usage': usage.get('how_to_use',''),
                'safety': safety.get('advice','')
            }
        }

    def render_product_page(self, product: ProductModel) -> Dict[str, Any]:
        benefits = [b['title'] for b in benefits_block(product)]
        usage = usage_block(product)
        safety = safety_block(product)
        price = price_block(product)
        return {
            'product_id': product.id,
            'name': product.name,
            'short_description': f"{product.concentration} with {' & '.join(product.ingredients)}. Suitable for {', '.join(product.skin_types)}.",
            'price': price,
            'concentration': product.concentration,
            'skin_types': product.skin_types,
            'ingredients': product.ingredients,
            'benefits': benefits,
            'usage': usage,
            'safety': safety,
            'tags': [t.lower().replace(' ','-') for t in (product.benefits + product.ingredients)][:8]
        }

    def render_comparison_page(self, a: ProductModel, b: ProductModel) -> Dict[str, Any]:
        comp_ing = compare_ingredients_block(a,b)
        benefit_overlap = list(set(a.benefits) & set(b.benefits))
        price_a = price_block(a)
        price_b = price_block(b)
        return {
            'title': f"{a.name} vs {b.name} — Comparison",
            'product_A':{
                'id':a.id,'name':a.name,'concentration':a.concentration,'ingredients':a.ingredients,'benefits':a.benefits,'price':price_a
            },
            'product_B':{
                'id':b.id,'name':b.name,'concentration':b.concentration,'ingredients':b.ingredients,'benefits':b.benefits,'price':price_b
            },
            'ingredient_comparison': comp_ing,
            'benefit_comparison': {
                'overlap': benefit_overlap,
                'A_only': [x for x in a.benefits if x not in benefit_overlap],
                'B_only': [x for x in b.benefits if x not in benefit_overlap]
            },
            'price_comparison': {
                'A_price': price_a.get('amount',0),
                'B_price': price_b.get('amount',0),
                'difference': abs(price_a.get('amount',0)-price_b.get('amount',0))
            },
            'recommendation_hint': self._recommendation_hint(a,b)
        }

    def _answer_stub(self, q, product):
        cat = q.get('category','')
        if cat=='Informational':
            return f"{product.name} contains {product.concentration} and is formulated to {', '.join(product.benefits)}."
        if cat=='Usage':
            return product.usage.get('how_to_use','Apply as instructed on label.')
        if cat=='Safety':
            return 'Patch test recommended; discontinue if irritation occurs.'
        return 'Please refer to product label or contact customer support.'

    def _recommendation_hint(self, a, b):
        pa = a.price.get('amount',0)
        pb = b.price.get('amount',0)
        hint = []
        if pa <= pb:
            hint.append(f"{a.name} is more budget-friendly.")
        else:
            hint.append(f"{b.name} is more budget-friendly.")
        if 'Hyaluronic Acid' in a.ingredients and 'Hyaluronic Acid' not in b.ingredients:
            hint.append(f"{a.name} adds hydrating benefits.")
        return ' '.join(hint)
